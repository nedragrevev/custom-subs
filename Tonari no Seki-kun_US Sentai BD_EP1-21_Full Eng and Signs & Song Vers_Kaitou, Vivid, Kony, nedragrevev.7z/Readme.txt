My Neighbor Seki (となりの関くん Tonari no Seki-kun) subs by Kaitou and Vivid (and Kony). Retimed by nedragrevev as of 10/01/2022; Dialogue Checked as of 13/08/2022.

• US Sentai Blu-ray Release

• Started with: Kony's release which muxed the best of Kaitou & Vivid's subs.
	Some changes made. They were mostly fixes/adjustments to make them work with this US Sentai BD encode.
	
• Credit to Kaitou and Vivid for most of the translation, typesetting and karaoke. One of the best examples of typesetting that I've seen. Also to Kony who remuxed the best of those two subs together.

------------------------------------

• January 2022 Revision (retiming!):

	Timing: All lines manually retimed. This was the whole point of this revision as the lines previously had absolutely terrible timings (in every way: lead in, lead out, wrong start time, lack of linking and keyframe snaps when required). I can't believe I released them like that).
	
	Translation:
		A few fixes and improvements in naturalness were needed. One or two grammatical corrections (at least one instance of an erroneous comma).
		Removed most of the dialog fades which I added in years ago before I knew what I was doing. A couple of them worked well so those remain untouched, but otherwise, most of them just didn't work.
		One or two interjections added back in because it made the subs flow more nicely.
		A few instances where I merged or split lines.
		
		Here are a few of the changes I can remember (there are a few more, but these are just so you can see I made the changes for a good reason):
		
		Episode 9 @ ~1m27s:
			Original: 		"Since I started knitting in first grade, I've continued to hone it, my one and only talent, over the years."
			Adjusted to:	"Since I started knitting in first grade, it's been the one and only talent that I've continued to hone over the years."
			
		Episode 10 @ ~4m46s:
			Original: 		"...and at night, they probably watch movies, just the two of them!"
			Adjusted to:	"...and at night, they probably watch movies together!" This translates the idea of 二人 (futari) just fine. "two of them" is a more literal translation but it sounds awkward here.
		And @ ~6m46s:
			Original:		"I've had my fill!"
			Adjusted to:	"Too much information!" This copies the English dub which is a much more natural translation of the idea. I made this change years ago.
		
		Episode 13 @ ~3m14s:
			Original: 		"A-Anyway, I need to put them somewhere they won't be too visible..." This was the untouched translation which is grammatically wrong.
			Adjusted to:	"A-Anyway, I need to put them someplace where they won't be too visible..." I've changed "somewhere" to "someplace" to avoid "somewhere where" which is fine in spoken English, but reads a bit awkwardly.

		Episode 14 @ ~2:33s:
			Original:		"He'd even sacrifice the valuable nutritional balance of a good lunch?" Sounds unnatural.
			Adjusted to:	"He'd even sacrifice the all-important nutritional balance of a good lunch?" More natural and still an accurate translation. 大切な (taisetsuna) --> "important" or "necessary"; 犠牲 (gisei) means "sacrifice" or "at the expense of".
		
	Typesetting: Basically untouched except for an improved fade in the Glasses episode (mpv wasn't rendering the fade nicely, so I changed from a simple fade to a complex one).

------------------------------------

This update: 13/08/2022
	Hardly any changes with this update.
	Full dialogue check complete.
		Only two minor errors found and fixed (episodes 13 & 14). That was it.
		Two instances where numbers over 10 where spelled out (episodes 12 & 13). Changed to numbers.
		A couple of instances if "Hm" adjusted to "Hmm".
		Removed two unnecessary commas (episodes 2 & 10).
		All " marks (ditto/inch mark) have been replaced with “ or ” as appropriate (proper quotation marks). This was the biggest change.
	
	It's now 100% error-free and most probably going to be the final release.

------------------------------------

TL;DR: Subs should now be an enjoyable watch.
