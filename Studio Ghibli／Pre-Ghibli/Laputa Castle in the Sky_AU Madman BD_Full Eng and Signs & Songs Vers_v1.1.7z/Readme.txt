Laputa: Castle in the Sky (天空の城ラピュタ | Tenkuu no Shiro Laputa) subs by ghsushsu123, hydes, Mysteria, nedragrevev (Last Update: 21/08/2022)

• AU Madman Blu-ray Release	
	If you haven't a different release, it may need to be resynced. I expect no more than ±1 second.
	Two script resolutions included: 1920 x 1036 (Cropped) & 1920 x 1080 (Full 16:9).

• Started With: THORA (Official Translation).
	Completely reworked in every aspect.

• Translation: nedragrevev (plus help from hydes and Mysteria)
	
	hydes made quite a few initial edits and alternative suggestions based on this script here: http://www.nausicaa.net/miyazaki/laputa/script_laputa_en.txt (I personally found this script had quite a few translation errors)
	
	Mysteria made some edits and gave some helpful suggestions.
	
	Then it came to me, where I retranslated most of the lines.
		The original Japanese of most lines have been carefully checked and thoroughly understood.
		Adjustments or new translations made where necessary. I relied on any edits, alternatives and suggestions from hydes and Mysteria where possible.
		Referenced the Disney dub at times, but I did notice that this dub differed from the Japanese significantly in quite a few lines.
	
• QC: hydes. He picked up a lot of mistakes. I've since watched it through and picked up a few more lines that needed adjusting and/or fixing. As of July 2022, a full dialogue check has been done.

• Timing: nedragrevev. I completely retimed the script I was given. I was told Mysteria had retimed everything, but the TPP was used (I might be wrong, but it appeared this way) when it really needed a manual check, so I manually retimed all lines.

• Typesetting: Mainly hydes (see his note below). He put in the work to customize it further to match the opening title.

• Songs: nedragrevev.
	Translation adjustments made. I don't really remember what I did here (this was completed 09/2021).
	hydes improved matching the style to the credits.

• I'm very confident these are error-free (even in the minor stuff), so these will likely be my last release for this movie. But you encounter any problems, please post on my Github issues page.

• Note from hydes: "THORA’s script, which uses the official translation, was first QC’d to a smaller extent by me (hydes), then checked and edited by Mysteria, and lastly, largely modified and polished by nedragrevev. The title card sign was done collectively by me, Mysteria, ghsushsu123, and nedragrevev. ED TS was done by nedragrevev."

tl;dr:
	ghsushsu123, hydes, Mysteria and myself (nedragrevev) all had something to do with these subs.
	Please enjoy!

Version History:

21/08/2022:
	One change only: "stomach ache" adjusted to "stomachache".
	
21/07/2022:
	Full dialogue check in a text editor complete.
		One very minor grammatical error fixed @ 1:12:04.96, "It's too crowded in here, so gimme a break!" The comma here was missing when it's grammatically required.
		Translation improvements. Except for the first one here which was changed completely, the following lines had minor changes:
			19m28s; 30m23s; 48m1s; 1h15m19s; 1h22m56s
		Consistency with interrobang. Five forceful statements meant as rhetorical questions ended with only an exclamation mark. I've adjusted it to interrobang.

12/03/2022:
	Multiple adjustments made to the translation and line timings. A few grammatical fixes.