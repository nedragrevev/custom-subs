Nausicaä of the Valley of the Wind English Subs by nedragrevev (Last Update: 19/07/2022)

• AU Madman Blu-ray Release. These should sync up well with most releases.
	Two script resolutions now included: 1920 x 1036 (Cropped) & 1920 x 1080 (Full 16:9).

• Translation: My own, based on the official Disney translation.
	Spent a fair bit of time translating the actual Japanese for most lines and then rendering it into natural English. I'm sure there's room for improvement but it's an improvement from the official stuff.
	Dub referenced in some cases, so some line are either copied from the dub or a modified version of them.
	
	August 2021: Big thanks to hydes for spotting a few mistakes and essentially QC'ing them himself. Motivated me to revise these, which I found was desperately needed as I obviously didn't check all the lines in my initial release.
		Quite a few fixes and some additional lines of dialog added (background dialog where I could make it out).
		Plenty of translation adjustments to better reflect the Japanese and flow more nicely. Much more carefully done for this revision.
		Changed "Ohmu" to the common noun "ohmu" as appropriate, since it's simply used to refer the "insects" in general.
		
	July 2022: Complete dialogue check in a text editor, the only reliable way of identifying every error, no matter how small.
		I'm confident these are now error-free. For more details of the changes, see the version history below.
		
• Timing: The August 2021 revision saw a full retiming of every line. Should present better than my first version.

• Typesetting. Only 5 signs needed typesetting from memory. Motion tracked to follow the screen jitter.
	I didn't see the purpose of typesetting the OP & ED credits.
	If you ever wondered what the WWF screen and blue screen at the beginning said, those have been translated and TS. Nothing important.
	
• Songs: N/A

• Versions:
	(1) Full English
	(2) Signs only. Matches the narration of the English dub.

As of the July 2022 update, I'm confident these are 100% error-free, but if you encounter any problems, please report them on my GitHub repository page.

Version History:

	19/07/2022 (v1.60):
		Full dialogue check through a plain text editor (for the first time, because I wasn't aware of the importance of this method of checking).
			All 8 remaining errors were identified and fixed. 6 of these were missing commas (unnoticeable in many cases, but an error is an error); and the other 2 were missing "'s" contractions.
			Minor translation improvements for a number of lines (naturalness). For example, "Everybody, get away to the high ground!" adjusted to "Everyone, get to high ground!"
		By chance, I stumbled on a line which wasn't timed correctly @ ~1h20m28s. Corrected. Translation also adjusted to reflect the repetition (see the line in question to understand what I mean).
		I'm confident this will be the final release as these have been checked for errors the right way (finally).

	29/06/2022:
		Minor grammatical fixes (thanks to trynan for spotting some of these). Some comma and apostrophe removals as required.
		Consistency with interrobang.
		More natural translation to one line @ ~1h27m52s.

	12/01/2022:
		Comma removal @ ~25m52s.
		Lowercase for "ushiabu" and "yamma" for the same reason "ohmu" is lowercase. 
		Line @ ~53m45s changed from "...from that battle" to "from the battle." Given the speaker was just in the battle herself, this minor change makes sense.
		Line @ ~54m02s changed from "The Yamma are sentries" to "Giant yammas are sentries."

Enjoy these subs!