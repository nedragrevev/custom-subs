Maquia: When the Promised Flower Blooms (『さよならの朝に約束の花をかざろう』) subs by nedragrevev (This Update: 4/09/2022)

• AU Madman Blu-ray Release.
	Encode starts at frame: 305 (as report by Handbrake). It's the first frame of the Japanese "Showgate" publisher ad.
	
	The subbed versions for all the standard editions seem to be hardsubbed. The workaround is easy:
		Demux the Japanese audio stream of your choice from the subbed mkv. Ignore the video stream.
		Mux that audio into your English dub mkv, which will be free of any hard subs. There should be no issues with A/V sync.

• Started with: Official (extracted and OCR'd from the US Limited Edition)
	Completely reworked

• Translation: This takes the best of the official and Mezashite's translations, and improves it further with my own adjustments for naturalness, accuracy and understanding.
	I've checked the Japanese for the majority of the lines, but not every single line. I didn't want to spends hours and hours on this.
	A fair amount of adjustments and improvements were made as necessary. Every single change/addition has been labeled in the line comments (excluding punctuation only adjustments). Search for "11arts".
	Quite a number of Mezashite's line translations were copied entirely, or with a few minor edits. They've been credited in the line comments if that's the case.
	Referenced and used the English dub for a few lines as their translation was pretty good.
	Lots of punctuation adjustments as the official translation was full of ellipses.
	
	Flashbacks at the end: the movement/effect used in kaiji's version worked really well, so I pretty much copied that.
	
	Two versions. The change is the rendering of the Iorph clan's epithet (both are valid translations):
		(1) "The Clan of Partings"		--> I personally prefer this, and Mezashite went with this too.
		(2) "The Clan of the Separated"	--> The official rendering which is also used in the English dub.

	No Japanese honorifics because it doesn't suit this movie. But for the English honorifics, I was consistent with my inclusion of "Princess" when referring to "Leilia-sama" and "Medmel-sama", with a few exceptions (for good reason). She's probably more like a concubine, but all but a few of the instances of "Leilia-sama" are either maids/servants or Commander Izor—all of whom would show proper respect. The dub went with "Princess" just about everywhere too, so I just followed that.

• Typesetting: Opening title typeset with the official EN title name. The font used in the official stuff (along with the small caps style) doesn't work well here, so I've chosen a more suitable font. No other signs present. Easiest typesetting ever.

• Timing: Carefully retimed all lines.

• ED Song: Simple fades were best here.
	Translation (was a bit lazy with this):
		Copied some verses from here: https://youtu.be/NFqmGmTj39U (Lyrics by hey ヽ(・v・)ﾉ)
		I made some minor adjustments to the official lines for a more poetic feel, but generally speaking, other than the replaced lines, the official stuff was a decent translation.
		
• Full dialogue check (the right way) has been completed. I'm confident it's completely error-free.

Please enjoy the final subs I've ever worked on! If you encounter any problems, feel free to post an issue on my repository's issues page.

Version History:

	4/09/2022
		Another tiny change: the official "But I..." adjusted to "Huh..." Again, this is at the very beginning.
	
	26/08/2022
		One tiny change: the official "Maquia, see you later!" adjusted to "Maquia, bye!" near the very beginning.