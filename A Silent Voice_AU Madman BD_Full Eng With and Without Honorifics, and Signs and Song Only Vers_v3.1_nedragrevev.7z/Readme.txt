A Silent Voice (聲の形 | Koe no Katachi) Subs by nedragrevev (July 2022 Revision (v3.1). This update: 14/07/2022)

• AU Madman Blu-ray Release. Should sync up fine with other releases.
	Script Resolutions Included:	1920 x 1036
									1920 x 1080 (Full HD with top and bottom black bars. The signs will not bleed into the black bars.)
	
• Started with: kametsu which is based on 35mm/LazyTS. 
	Most of the credit for these subs goes to these two groups.
	Though in this revision, I've put in a bit more effort: adjusting a fair amount of the typesetting, redoing the ED song, some more translation adjustments, and some timing adjustments.

• Translation: 35mm. Some changes and fixes here and there, but they were done quickly. I didn't want to spend time on these subs so translating wasn't a focus with these.
	Honorifics version created.
	
	Revisions:
		Translation mistakes fixed and more adjustments as necessary. Changes were made with much more care this time around.
		Hesitations (e.g. "H-Huh?" "U-Uh...") have been minimized. Thanks to hydes for advising about these.
		(Also see the update below)
	
• Timing: Complete manual retiming.

• Typesetting: kametsu/LazyTS had good typesetting. Some blur isn't quite right and I don't think I fixed it all. Most of it should look ok, though.
	Honorifics added in for that version.
	
	Revisions:
		Removed some text message masks and adjusted typesetting to match the Japanese. Whenever it's possible, I don't like to mask Japanese signs, and in many cases there were many masks when there didn't need to be.
		Adjusted/fixed some of the oddly x-scale stretched signs. I'm not sure if this was intentional but in many places, having the text stretched horizontally looked worse.
		English title typeset to match the official English posters/case covers. It's a vector drawing so if this doesn't look right, check your video resolution and use the version which matches.
		A few new signs translated and typeset.
		Other minor fixes and changes elsewhere, and some better tracking data applied for one set of signs.

• ED Song: Completely overhauled. It should present well, and the translation should make a little bit more sense.
	Translation: Spent a fair bit of time carefully translating the verses as the one kametsu/LazyTS went with didn't make much sense. The lyrics themselves are hard to understand; a few verses still don't make much sense to me, but these flow and connect in some way without straying from the Japanese.
	
	K-effect: As I don't have the original template (or the timings), I did my best to recreate the effects used, with some changes.
		
	Official Anime Music Video: Since my BD included this, I created some subs specifically for this. Note that the timings differ slightly to the Movie ED version as the song progresses. This script has a 1080p resolution.

• As of this July 2022 version, I'm confident this is error-free, and presents really well, so it will likely be the final release. But if you have any problems, please post on my GitHub issues page and I will fix it as soon as I get to it. Suggestions are also welcome.

tl:dr: Enjoy these subs!

This update: 14/07/2022.
	Complete dialogue check.
		No significant errors were found (except for a few awkward sentences which were adjusted). However...
		Translation improvements were made. Some of these changes are pretty significant to me (the lines below marked with an asterisk), but most of them are relatively minor, though definite improvements.
			See lines @: 19m01s; 35m21s; 41m07s; 43m24s; 49m01s; 52m37s; 1h00m15s; 1h00m27s; 1h33m21s; *1h39m17s*; 1h39m23s; 1h39m26s; 1h41m32s; 1h53m22s - 45s; *2h00m30s - 35s*; 2h00m56s; 2h01m47s;
		All instances of "stomach ache" adjusted to "stomachache".
		A few minor adjustments to optional punctuation for better flowing subs.
		"No Honorifics & Western Naming Order": All food was localized in this version. For example, takoyaki was rendered as "octopus balls", and yakisoba as "fried noodles".
	I consider this the final, error-free release.