ARIA The ORIGINATION & Picture Dramas, subs by nedragrevev (This update: 21/08/2022)

• US Kickstarter Blu-ray Release
	Encode dimensions: 1920 x 1080

• Started with: SallySubs. Completely reworked.

• Translation: Started off with the official subs but made a number of changes. I found the official Nozomi subs were a bit too literal, and quite a few lines didn't flow well.
	You be the judge, but I hope you find this translation as cleaner, more natural, and easier to understand English, while keeping true to the Japanese dialogue.
	No need to go into details but worth mentioning that as I did with S1 & S2, honorifics have been added back in. Except for Kohai-chan. I used the official: "Junior".
	Interjections: Somewhat "translated", but I'm not entirely satisfied with this. Should be improved from the official translations, though.

• Timing: Every line manually retimed. Hopefully you'll find it presents really well.

• Typesetting: Little typesetting needed here. Adjustments made to SallySubs typesetting so the signs have more accurate blur and the correct color to match the Kickstarter release.

• Songs:
	Karaoke effects to match with what I did with S1.
	This time I placed both the Romaji and English on the left, which is the norm. Seemed to work better since it's now widescreen.
	EP5.5 had 3 different versions. The difference was in the insert song (Yokogao no Yume - "Birdcage Dream"): (1) Simple fade; (2) Wave effect but no K-timing; (3) Fade with K-timed shine effect. It was near impossible to accurately K-time this, even with the CD album audio, so in a few lines I just timed it to the beat as best as I could.
	EP07 also has Birdcage Dream as an insert song, but since I preferred the plain wave effect, I simply used that and made no other versions.
	
• Chapter Markers included which are frame accurate.

• As of the August 2022 update, they are error-free, but if you encounter a problem, or have suggestions, feel free to post a bug on my GitHub repository's issues page.

Hope these subs work for you. Enjoy.

Version history:

21/08/2022
	Only one adjustment, which affects episode 5: "Hi, Miss" adjusted to "Hi Miss" (comma removed). Grammatically, the first one is correct, but it just doesn't flow well. It's very common to see this without a comma, anyway.

12/08/2022
	Full dialogue check completed.
		All errors have been identified and fixed. Not many at all, and they were mostly minor stuff. A lot of the issues were with the official Nozomi translation.
		Some translation improvements. That included consistency with honorifics used for titles ("Mr. Mailman" or "Miss Undine," etc.)
		Interjections: Most "Ah" changed to "Oh" with one or two exceptions.
		Consistency with other seasons for food, interjections, and other translation choices.
	Improvements to the k-effect for Alice's song in episode 9.
	Timing adjustments to a few lines (which were previously flagged).
	
	Now error-free, these are likely to be the final release.