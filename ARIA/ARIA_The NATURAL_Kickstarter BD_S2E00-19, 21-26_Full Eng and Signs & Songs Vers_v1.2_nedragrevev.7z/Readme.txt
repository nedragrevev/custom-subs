ARIA The NATURAL subs by nedragrevev (This update (v1.2): 11/08/2022)

• US Kickstarter Blu-ray Release

• Encode size and crop info for encoding the Kickstarter BD's (same as S1):
	Resolution: 1424x1064
	Picture Crop Settings:
		Left:	248
		Right:	248
		Top:	10
		Bottom: 6
	
	This gave the best picture with minimal loss of picture, no bright edges, and obviously, as centered as possible.
	If you have a different size encode, the dialogue will resize fine, but the typesetting may be a few pixels off. Apologies.

• Started with: SallySubs.

• Translation: Started off with the official subs and made quite a number of changes. Didn't spend as much time on translation as I did with season 1, though.
	Honorifics have been added back in. The exception is with Kohai-chan. I used the official: "Junior".
	The mailman. When Akari addresses him directly it's "Mr. Mailman", but when she talks about him to someone else, it's "the mailman". Even though this translation includes honorifics, this makes far more sense for a title as opposed to a name.
	Interjections: Very quick revision saw these "translated," so the lines make more sense. Nozomi simply transliterated the interjections, which I initially followed, but a lot of interjections like "Ah" and "Eh" have different meanings for English speakers.
	
	You be the judge, but I hope you find this translation as more natural, easier to understand English, while keeping true to the Japanese dialogue. As of August 2022, this should be even more so (though I'm still not completely satisfied with them, they are an improvement).

• Timing: Every line carefully retimed.

• Typesetting: Little TS needed here, but more than in the first season.

• Songs:
	Translation changes made.
	Karaoke effects to match with what I did with S1. Most insert songs just had the simple shine/highlight effect as it would other be too distracting with some fancy effect.
	Romaji placed top left and English on the top right to match what I did for S1. I wanted something as unobtrusive as possible, so I didn't want a really long second line that cut into the middle of the picture.
	
• Chapter markers included which are frame accurate.

• Where's EP20? I didn't forget about it, I just didn't sub this episode so haven't included it.

• Any mistakes, issues or improvements? Feel free to post an issue on the GitHub tracker page.

Hope these subs work for you. Enjoy.

This Update: 11/08/2022
	Full dialogue check completed for all lines in all episodes.
		All remaining errors identified and fixed, that includes minor stuff like correct usage of commas and such (most of which were down to the official Nozomi translation). Overall, there weren't as many errors as in season 1.
	Translations improvements. A number of improvements to naturalness, but I have to say, I'm not really satisfied with the translation, especially with all the interjections. I'm just not motivated to edit it further, though. This review took longer than expected as it is.
		Consistency with all the seasons, including Akira's angry interjection, "すわ！" (Suwa!) has been adjusted to either "Hey!" or "Enough!" depending on the context.
		Localized one of Al's puns in episode 25. It's not great, but it's better than including a translators note. And his jokes are lame so it didn't need to make much sense.
		"President" adjusted to "Mr. President" where no specific name was attached. I think I did this for season 3.
		"Wha—?!" adjusted to "What?!" or something else appropriate. These quickly become annoying.
		Punctuation near quotes: where it's a quote from what someone said, the punctuation is inside the quotation mark, anything else it is outside (titles or replicating the air-quote thing people do to emphasize one word).
	Food: Consistency with other seasons/specials, so most of the Japanese names for food have been re-added.
	
	This is now error-free, so it will probably be the final release. Since there weren't that many errors, I'm just calling this v1.2.