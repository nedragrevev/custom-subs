ARIA The ARIETTA English subs by nedragrevev (This update: 8/08/2022)

• US Kickstarter Blu-ray Release.
	Encode dimensions: 1920 x 1080
	
• Started with: Official Nozomi Subs (OCR)

• Translation: Very few adjustments made here. It's basically still the official Nozomi translation.
	Some improvements made for naturalness, nothing special to note. Adjustments to some interjections.
	
• Timing: Fully retimed as I always do. Should present well.

• Songs:
	Karaoke effects in with previous seasons.
	
• Typesetting: None. No signs to be seen here.

• If you encounter any issues, don't hesitate to post an issue on my repository's tracker page.

Enjoy!

This update: 8/08/2022
	Full dialogue check completed.
		No significant errors found, just a few stray commas and other punctuation that needed removing from the official Nozomi translation.
	Adjustments to most of the interjections so it's less annoying (maybe).
	A few adjustments to the script for naturalness and easier reading/improved flow.
	
	Now completely error-free, this is likely to be the final release. I'm also calling this v1.2 to avoid confusion with the season 2 (as in, this has been checked and reviewed at the same time as that season).