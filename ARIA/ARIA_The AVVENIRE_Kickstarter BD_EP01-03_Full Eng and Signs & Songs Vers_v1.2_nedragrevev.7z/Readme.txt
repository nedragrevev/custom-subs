ARIA The AVVENIRE OVA subs by nedragrevev (This Update: 12/08/2022)

• US Kickstarter Blu-ray Release
	Encode dimensions: 1920 x 1080

• Started with: Official Nozomi Subs (OCR'ed)

• Translation: As above, started off with the official subs but made a a number of what I saw as needed changes.
	Overall, after checking the translations of most of the dialogue, I found they reflected the Japanese really well. But there were some lines that didn't flow well and needed changing.
	Interjection: For Akari's "Eh" response to Aika's "No sappy lines allowed", I regret not translating this from the first season as "Aww..." It's still not perfect but I think it fits better than "Huh?" It's not that big a deal and I don't want to go back and redo 50+ episodes just for that.

• Timing: Fully retimed. Should present well.

• Typesetting: Little TS needed here. The round calendar in episode 1 is an edit from SallySubs (because why bother re-typesetting when good work was already done), which was the only noteworthy sign in these 3 episodes. There was only one other sign in episode 3 (not counting the episode titles) which needed TS.

• Songs:
	Karaoke effects in with previous seasons. Nothing special to note.

• Chapter Markers included which are frame accurate.

• As of August 2022 I'm confident these are 100% error-free, but should you encounter any problems or have a suggestion, feel free to post a bug on my GitHub custom-subs repository page.

Hope these subs work for you. Enjoy.

This update: 12/08/2022
	Full dialogue check complete.
		Two errors were identified and fixed. Both were in the third episode/chapter and minor ("we're" fixed to "were" and an unnecessary comma).
		More translation improvements. Most of the translation was good, except for a few weirdly rendered lines. Now fixed.
		Tweaked the k-effects for Athena's insert song in the last episode/chapter (in the same way I did for Alice's song in S03E09).
	Overall, I did not make many adjustments, but the adjustments I did make are improvements nonetheless.
	
	These were already solid releases, but they should be even better now. I'm confident these are 100% free of any errors, even minor stuff. So it will probably be the final release.
	
	For the sake of consistency with the other seasons and special I just reviewed, I've labeled the updates as "v1.2", but in reality it's more like "v1.01".