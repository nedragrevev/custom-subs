5 Centimeters per Second 『秒速5センチメートル』 subs by nedragrevev (This Update: 3/07/2022)

• Japanese International/Global Blu-ray Edition.

• Started with: kuchikirukia
	Completely reworked

• Translation: Initially used edits from a mix of subs including: "kuchikirukia", "nizzk" & "BluDragon"
	July 2021 revision: I made some translation improvements. Note that I only carefully thought about some lines; full translation work still wasn't done. From what I briefly looked at when retiming, it seemed quite accurate and natural.
	Now includes two versions without honorifics: (1) retains name order as spoken; (2) western naming order.
	
	As of July 2022, the translation should present extremely well.

• Typesetting: Fully revised for the July 2021 revision. Significant changes and improvements all round.
	Other notes for this revision:
		Actual translations of the signs (for the initial subs I edited years ago, I simply accepted the "translation" of signs already present, which were wrong for a number of signs).

• Timing: Retimed everything again for the July 2021 revision.

• ED Song: Karaoke effect added. The template is not mine, and I'm not sure who to credit for it as it was just something I found floating around the internet.
	Revised version sees a few minor style adjustments which makes the lyrics stand out more clearly (no alpha/transparency).

• Four Versions (because we all have our own preferences):
	(1) Honorifics
	(2) No honorifics (signs to match)
	(3) No honorifics and western naming order (signs to match)
	(4) Signs and song only (western naming order, obviously)

Hope you enjoy!

This July 2022 update is likely the final release, but if you happen to come across an problem, please let me know on my GitHub issues page.

Version history:

	3/07/2022:
		Complete Dialogue Check:
			Any remaining grammatical errors have been spotted and fixed (there were only four). I'm confident this is now error-free.
			Addition of one Oxford comma.
		As mentioned, these will very likely the final update.

	8/01/2022:
		Background dialog translated and now showing @ ~5m54s.