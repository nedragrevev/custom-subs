へやキャン△ (Room Camp △) English Subs by nedragrevev

• JP Blu-ray Release

• Started with: asenshi's subs. They did an excellent job typesetting this. Good translation adjustments/improvements from Crunchyroll's stuff.

• Translation: Minor adjustments but asenshi's translation was just about spot on.
	Localizations: asenshi went with a different direction from season 1, choosing to keep a lot of the Japanese food/dish names. To be consistent, I translated consistently to match with my S1 Yuru Camp subs. eg. "kaarage" was changed to "fried chicken." There were a few others but I can't remember off the top of my head.
	
	Episode 8 has two versions: (1) Localized. "Wafer Sandwich"; (2) Unlocalized. "Monaka". I nearly changed the "white bean paste" to "shiro-an" in this version but I don't think that's widely known (not that monaka is that widely known either, but meh...), so I left as is.

• Timing: All lines checked, with some minor fixes, adjustments and improvements made. asenshi actually timed these quite well, though I still think their threshold for keyframe snapping and linking lines is too small for my taste.

• Typesetting: Minor adjustments/fixes/improvements and a couple of additions. As mentioned, asenshi did an extremely good job and made adjusting these subs for my own BD encodes a breeze.

• Songs: Simple karaoke effect added for the ED.
	Adjusted translation slightly, and repositioned to be in the middle. It's subjective, but for my taste, I preferred the lyrics there. I wanted this to be in the bottom half of the video where all the white is, but the credits are in the way.

• Any issues or mistakes or suggestions can be reported/made on my Github page.

The tl;dr version. Hope you enjoy these subs! Props to asenshi for their typesetting, made it a lot easier to do these.

This update: 17/07/2022:
	Complete dialogue check. Extremely minor adjustments to a few of the episodes:
		One error was found and fixed ("manjuu" to "manju").
		A few words were in British English for some reason. Fixed to American English.
		"Koufu" & "Nikkou" was adjusted to "Kofu" and Nikko" which is the accepted spelling in English.
		"Mt." adjusted to "Mount" for consistency.
	It is highly likely that this will be the last release.