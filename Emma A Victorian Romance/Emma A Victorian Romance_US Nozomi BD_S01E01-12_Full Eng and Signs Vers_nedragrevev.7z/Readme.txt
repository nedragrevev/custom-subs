Emma: A Victorian Romance [S01] (英國戀物語エマ | Eikoku Koi Monogatari Emma) Subs by nedragrevev (This Update: 27/08/2022)

• US Nozomi Blu-ray Release.

• Started with: Official Nozomi Subs (Extracted)

• Translation: Minor work. The official Nozomi translation was, for the most, pretty accurate.
	A few translation adjustments to improve accuracy and/or flow. Not the focus of this release, as I wanted a break from heavy translating and typesetting.
	Fixes: For an official script, there were too many mistakes (misplaced or missing words) so these have been fixed.
	Grammar: The official stuff overused punctuation (understatement), particularly ellipses and commas, so quite a lot of adjustments were made here.
	
	Episode 1 has one translators note to explain what the "Season" is. If this is period accurate, it shouldn't be capitalized, but for the moment, I feel like it needs to be differentiated from the four climatic seasons.

• Timing. Completely and carefully retimed as usual.

• Typesetting: Just the chapter/title openings.
	The Nozomi release had clean chapter/episode titles for season 1, so I've matched it up with the title signs in season 2, which left in the JP (not sure why they were inconsistent with this, but anyway.)

• Chapter XML files included as the chapter markers on the BD's weren't accurate.

• As of August 2022, I'm confident these are error-free and present really well, but if you do encounter any issues, please create an issue on my repository's issues page.

tl:dr: Enjoy these subs!

Last Update: 27/08/2022
	Full dialogue check completed.
		No significant errors found, just a few missing or oddly placed commas (from Nozomi's translation). Now fixed.
		A few minor adjustments for naturalness. Some "Ah" interjections have been adjusted to "Oh" where appropriate.
		One instance of "theatre" adjusted to "theater" and two instances of "Phew" adjusted to "Whew" as per American English.
	Overall, few changes were made, so it probably won't be noticeable.
	This is highly likely to be the final release.