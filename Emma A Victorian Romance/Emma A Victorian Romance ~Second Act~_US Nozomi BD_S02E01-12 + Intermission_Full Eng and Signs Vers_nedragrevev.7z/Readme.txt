Emma: A Victorian Romance ~Second Act~ [S02] (英國戀物語エマ ～メルダース編～ | Eikoku Koi Monogatari Emma ~Mölders Hen~) Subs by nedragrevev (This Update: 27/08/2022)

• US Nozomi Blu-ray Release.

• Started with: Official Nozomi Subs (Extracted)

• Translation: Minor work as with season 1.
	Same issues with the official subs as with season 1. For an official translation, the amount of mistakes were surprising. And the amount of ellipses and commas used was unnecessary.

• Timing. Completely and carefully retimed manually as I usual.

• Typesetting: Simplest typesetting ever, just the opening and ending chapter/title signs.

• Chapter XML files included. As with season 1, the chapter markers on the BD's weren't accurate.

• As of this August 2022 release, I'm very confident this is error-free, but if you encounter any problems, don't hesitate to let me know on my repository's issues page.

tl:dr: Enjoy these subs!

Last Update: 27/08/2022.
	Full dialogue check completed.
		No significant errors found. The same issues as with season one, some erroneous or missing commas. That was it.
		Some "Ah" interjections adjusted to "Oh" as appropriate (it wasn't always the better choice).
		A few translation adjustments for naturalness.
	As with season 1's dialogue check which I just completed, overall, few changes were made, so it probably won't be noticeable.
	This is highly likely to be the final release.